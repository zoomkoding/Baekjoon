#include <cstdio>
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <algorithm>
#include <stack>
#include <queue>
#include <map>
#include <cmath>
using namespace std;

int n, ans;

int main(){
    scanf("%d", &n);
    printf("%d", ans);
}