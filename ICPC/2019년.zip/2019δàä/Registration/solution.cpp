#include <cstdio>
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <algorithm>
#include <stack>
#include <queue>
#include <map>
#include <cmath>
using namespace std;

int n;
int main(){    
    printf("%s\n%s", "team210", "yyj5wqdc");
    // printf("%s\n%s", "Negend", "yyj5wqdc");
    // printf("%s\n%s", "team210", "Negend");
    // printf("%s\n%s", "Negend", "team210");

}