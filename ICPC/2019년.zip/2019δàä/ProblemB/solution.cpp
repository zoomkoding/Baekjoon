#include <cstdio>
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <algorithm>
#include <stack>
#include <queue>
#include <map>
#include <cmath>
using namespace std;

int n, ans, arr[1000001][2];

int main(){
    //0이 같을 때 1이 다를 때
    arr[1][1] = 2;
    scanf("%d", &n);
    for(int i = 1; i <= n; i++){
        arr[i+1][1] = (arr[i][0] * 2) % 16769023;
        arr[i+1][0] = arr[i][1];
    }
    printf("%d", (arr[n][0] + arr[n][1]) % 16769023);
}